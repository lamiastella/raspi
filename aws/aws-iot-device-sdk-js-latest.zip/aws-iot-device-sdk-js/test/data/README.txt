This directory contains data files used during unit testing.

The client certificate (certificate.pem.crt), private key (private.pem.key),
and root CA certificate (root-CA.crt) in this directory are not valid; they
are for testing purposes only and cannot be used to connect with the AWS IoT
platform.
